package com;

import java.util.Scanner;

public class TestBook {
public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
        
        System.out.println("Enter the Book name:");
        String bookname=sc.nextLine();
        
        System.out.println("Enter the price:");
        double price=sc.nextDouble();
        sc.nextLine();
        
        
        Book obj=new Book();
        obj.setBookTitle(bookname);
        obj.setBookPrice(price);
        System.out.println("Book Details presented in the library");
        System.out.println("Book Title :"+obj.getBookTitle());
        System.out.println("Book Price :"+obj.getBookPrice());
       
    }
}
