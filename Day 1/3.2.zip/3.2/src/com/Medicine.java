package com;

public class Medicine {
	public void displayLabel()
	{
	System.out.println("Company : Chandana's Pharmacy");
	System.out.println("Address : Chirala");
	}
	}
	class Tablet extends Medicine
	{
	public void displayLabel()
	{
	System.out.println("store below 20 degree celsius");
	}
	}
	class Syrup extends Medicine
	{
	public void displayLabel()
	{
	System.out.println("Physician prescription should be complusory");
	}
	}
	class Ointment extends Medicine
	{
	public void displayLabel()
	{
	System.out.println("only for external use");
	}
}
