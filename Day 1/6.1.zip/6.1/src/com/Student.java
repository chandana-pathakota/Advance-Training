package com;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Student {
public static void main(String[] args) {
		
		ArrayList<String>a=new ArrayList<String>();
		a.add("Chandana");
		a.add("Priya");
		a.add("Janu");
		a.add("Mounika");
		a.add("Bhaskar");
		a.add("Nivas");
		a.add("Mahi");
		a.add("Srikanth");
		
		System.out.println("List of students are :");
		for(String str:a)
		{
			System.out.println(str);
		}
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the name of student to be searched:");
		String srt=sc.next();
		int position=Collections.binarySearch(a, srt);
		System.out.println("position of "+" " +srt+" "+ "is :"+position);
	}
}
