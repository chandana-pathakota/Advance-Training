package com;

import java.util.LinkedList;

public class Main {
	public static void main(String[] args) 
	{
		LinkedList<Employee> v=addInput();
		display(v);
	}
	public static LinkedList<Employee> addInput()
	{
		Employee e1=new Employee(601,"Chandana","Chirala");
		Employee e2=new Employee(602,"Mounika","Hyderabad");
		Employee e3=new Employee(603,"Surya","Bangalore");
		Employee e4=new Employee(604,"krishna","Hyderabad");
		
		LinkedList<Employee>l = new LinkedList<Employee>();
		l.add(e1);
		l.add(e2);
		l.add(e3);
		l.add(e4);
		return l;
	}
	public static void display(LinkedList<Employee>v)
	{
		for(Employee e:v)
		{
			System.out.println(e.getEmpid()+"\t"+e.getEmpName()+"\t"+e.getAddress());
		}

	}
}
